# echarts3-chinese-map-drill-down
Echarts3中国地图下钻至县级

demo：https://flute.github.io/echarts3-chinese-map-drill-down/

![map drill down](./static/img/map.gif)
